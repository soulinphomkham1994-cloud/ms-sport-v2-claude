// ====================================================
// MS SPORT — Google Apps Script Backend
// ວາງໂຄດນີ້ໃສ່ Google Apps Script ແລ້ວ Deploy ເປັນ Web App
// ====================================================
// ຂັ້ນຕອນ:
// 1. ເປີດ Google Sheet → Extensions → Apps Script
// 2. ລຶບໂຄດເດີມທັງໝົດ → ວາງໂຄດນີ້ທັງໝົດ
// 3. ກົດ Save (💾)
// 4. Deploy → New deployment → Web app
//    - Execute as: Me
//    - Who has access: Anyone
// 5. Copy URL ທີ່ໄດ້ → ໃສ່ໃນ app ທີ່ຊ່ອງ "Apps Script URL"
// ====================================================

const SHEET_NAME   = '2026';
const INV_COL      = 5;   // Column E = Invoice No
const STATUS_COL   = 6;   // Column F = Status (dropdown)

function doPost(e) {
  try {
    const raw  = e.postData ? e.postData.contents : '{}';
    const data = JSON.parse(raw);
    const inv    = (data.inv    || '').toString().trim().toUpperCase();
    const status = (data.status || '').toString().trim();

    if (!inv || !status) {
      return respond({ success: false, message: 'Missing inv or status' });
    }

    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) {
      return respond({ success: false, message: 'Sheet "' + SHEET_NAME + '" not found' });
    }

    const lastRow = sheet.getLastRow();
    if (lastRow < 1) {
      return respond({ success: false, message: 'Sheet is empty' });
    }

    const colValues = sheet.getRange(1, INV_COL, lastRow, 1).getValues();
    let targetRow   = -1;

    for (let i = 0; i < colValues.length; i++) {
      const cell = (colValues[i][0] || '').toString().trim().toUpperCase();
      if (cell === inv) {
        targetRow = i + 1; // 1-indexed
        break;
      }
    }

    if (targetRow === -1) {
      return respond({ success: false, message: 'ບໍ່ພົບໃບກຳກັບ ' + inv + ' ໃນ Sheet' });
    }

    // ຂຽນສະຖານະລົງ Column F
    sheet.getRange(targetRow, STATUS_COL).setValue(status);

    // ຂຽນ timestamp ລົງ Column G (ເວລາອັບເດດ)
    const now = new Date();
    sheet.getRange(targetRow, STATUS_COL + 1).setValue(
      Utilities.formatDate(now, Session.getScriptTimeZone(), 'dd/MM/yyyy HH:mm:ss')
    );

    return respond({
      success : true,
      message : 'ອັບເດດ ' + inv + ' → ' + status + ' ສຳເລັດ (ແຖວທີ ' + targetRow + ')',
      row     : targetRow
    });

  } catch (err) {
    return respond({ success: false, message: err.message || 'Unknown error' });
  }
}

// ======= ຟັງຊັນ GET — ໃຊ້ທົດສອບວ່າ deploy ສຳເລັດ =======
function doGet(e) {
  return respond({ success: true, message: 'MS SPORT Apps Script is running ✅' });
}

function respond(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
