# 🏭 MS SPORT Scanner v2 — Vercel + Google Apps Script

ລະບົບໃໝ່ທີ່ງ່າຍກວ່າ: **ບໍ່ຕ້ອງ install package ໃດໆ** — Vercel deploy ແຕ່ HTML ໄຟລ໌ດຽວ

---

## 📁 ໂຄງສ້າງ

```
ms-sport-v2/
├── public/
│   └── index.html          ← UI ຫຼັກ (ສະແກນ + ໃສ່ URL + ເລືອກສະຖານະ)
├── apps-script-code.js     ← ໂຄດທີ່ຕ້ອງວາງໃສ່ Google Apps Script
├── package.json            ← ບໍ່ມີ dependencies (deploy ທັນທີ)
├── vercel.json             ← config ງ່າຍ
└── README.md
```

---

## 🚀 ຂັ້ນຕອນ Deploy

### ຂັ້ນທີ 1 — ຕັ້ງຄ່າ Google Apps Script

1. ເປີດ Google Sheet: `https://docs.google.com/spreadsheets/d/1lPp5LuwT6lAt0wozRduI8ErarHk-5iwI5PWoZwmTZoY/`
2. ກົດ **Extensions → Apps Script**
3. ລຶບໂຄດເດີມທັງໝົດ → ເປີດໄຟລ໌ `apps-script-code.js` → **copy ທັງໝົດ** → ວາງໃສ່
4. ກົດ **Save** (💾 Ctrl+S)
5. ກົດ **Deploy → New deployment**
6. ຕັ້ງຄ່າ:
   - Type: **Web app**
   - Execute as: **Me**
   - Who has access: **Anyone**
7. ກົດ **Deploy** → ກົດ **Authorize access** → Copy **Web app URL**

> URL ຈະໜ້າຕາແບບນີ້:
> `https://script.google.com/macros/s/AKfycby.../exec`

---

### ຂັ້ນທີ 2 — Upload ຂຶ້ນ GitHub

```bash
git init
git add .
git commit -m "MS SPORT Scanner v2"
git remote add origin https://github.com/YOUR_USERNAME/ms-sport-scanner.git
git push -u origin main
```

> ⚠️ ຖ້າ repo ເດີມຍັງຢູ່ — ໃຫ້ລຶບໄຟລ໌ເດີມໃນ GitHub ທັງໝົດ ແລ້ວ upload ໄຟລ໌ໃໝ່ຈາກ zip ນີ້ແທນ

---

### ຂັ້ນທີ 3 — Deploy ບົນ Vercel

1. ໄປທີ່ [vercel.com](https://vercel.com) → ເລືອກ repo → Deploy
2. **ບໍ່ຕ້ອງຕັ້ງ Environment Variables ໃດໆ** (ໃຊ້ Apps Script ແທນ)
3. ຫຼັງ deploy ສຳເລັດ → ເປີດ URL → ໃສ່ Apps Script URL ໃນຊ່ອງສີເຫຼືອງ → ກົດ **ບັນທຶກ URL**

---

## 📱 ວິທີໃຊ້ງານ

1. ເປີດ app → ໃສ່ **Apps Script URL** ໃນຊ່ອງສີເຫຼືອງ → ກົດ **ບັນທຶກ URL**
2. ເລືອກ **ສະຖານະ** ຈາກ dropdown
3. ກົດ **ເປີດກ້ອງຫຼັງ** → ສ່ອງ QR Code
4. ລະບົບຈະ update Google Sheet ທັນທີ ✅

URL ຈະຖືກ save ໃນ browser — ຄັ້ງໜ້າບໍ່ຕ້ອງໃສ່ໃໝ່

---

## 🗂️ ໂຄງສ້າງ Google Sheet (Sheet: 2026)

| ... | **E — Invoice No** | **F — Status** | **G — ເວລາອັບເດດ** |
|-----|--------------------|----------------|---------------------|
| ... | INV-001            | ກຳລັງພິມແບບ P1 | 28/03/2026 10:35:00 |
| ... | INV-002            |                |                     |
